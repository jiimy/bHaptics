import React from "react";

const FilterGroup = ({ children }) => {
  return <>{children}</>;
};

export default FilterGroup;
