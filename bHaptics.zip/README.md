# 설치

압축 해제 후 npm i 

# 실행

npm run start

## ui 
- 필터 드롭다운의 펼쳐진 리스트의 높이는 선택된 높이의 75%인 45px로 잡았습니다. 
- outofclick hooks로 드롭다운 바깥 클릭시 닫히게 했습니다. 

## 상태관리
- 상태관리로 redux toolkit 을 사용했습니다.